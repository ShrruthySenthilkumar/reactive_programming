package com.reactive.ReactiveDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
